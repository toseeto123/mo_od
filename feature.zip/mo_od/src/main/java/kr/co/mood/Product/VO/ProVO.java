package kr.co.mood.Product.VO;

import org.springframework.web.multipart.MultipartFile;

public class ProVO {
	String pro_serialnumber, pro_categoryserial, pro_name, pro_maindesc, pro_maindesctitle , pro_subdesc, pro_option1, pro_option2, pro_option3;

	int pro_number, pro_paycount, pro_bucketcount, pro_price, pro_soldout;

	private MultipartFile file, file2, file3, file4, file5;

	private String pro_img1, pro_img2, pro_img3, pro_img4, pro_img5;

	public String getPro_serialnumber() {
		return pro_serialnumber;
	}

	public void setPro_serialnumber(String pro_serialnumber) {
		this.pro_serialnumber = pro_serialnumber;
	}

	public String getPro_categoryserial() {
		return pro_categoryserial;
	}

	public void setPro_categoryserial(String pro_categoryserial) {
		this.pro_categoryserial = pro_categoryserial;
	}

	public String getPro_name() {
		return pro_name;
	}

	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}

	public String getPro_maindesc() {
		return pro_maindesc;
	}

	public void setPro_maindesc(String pro_maindesc) {
		this.pro_maindesc = pro_maindesc;
	}

	public String getPro_maindesctitle() {
		return pro_maindesctitle;
	}

	public void setPro_maindesctitle(String pro_maindesctitle) {
		this.pro_maindesctitle = pro_maindesctitle;
	}

	public String getPro_subdesc() {
		return pro_subdesc;
	}

	public void setPro_subdesc(String pro_subdesc) {
		this.pro_subdesc = pro_subdesc;
	}

	public String getPro_option1() {
		return pro_option1;
	}

	public void setPro_option1(String pro_option1) {
		this.pro_option1 = pro_option1;
	}

	public String getPro_option2() {
		return pro_option2;
	}

	public void setPro_option2(String pro_option2) {
		this.pro_option2 = pro_option2;
	}

	public String getPro_option3() {
		return pro_option3;
	}

	public void setPro_option3(String pro_option3) {
		this.pro_option3 = pro_option3;
	}

	public int getPro_number() {
		return pro_number;
	}

	public void setPro_number(int pro_number) {
		this.pro_number = pro_number;
	}

	public int getPro_paycount() {
		return pro_paycount;
	}

	public void setPro_paycount(int pro_paycount) {
		this.pro_paycount = pro_paycount;
	}

	public int getPro_bucketcount() {
		return pro_bucketcount;
	}

	public void setPro_bucketcount(int pro_bucketcount) {
		this.pro_bucketcount = pro_bucketcount;
	}

	public int getPro_price() {
		return pro_price;
	}

	public void setPro_price(int pro_price) {
		this.pro_price = pro_price;
	}

	public int getPro_soldout() {
		return pro_soldout;
	}

	public void setPro_soldout(int pro_soldout) {
		this.pro_soldout = pro_soldout;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public MultipartFile getFile2() {
		return file2;
	}

	public void setFile2(MultipartFile file2) {
		this.file2 = file2;
	}

	public MultipartFile getFile3() {
		return file3;
	}

	public void setFile3(MultipartFile file3) {
		this.file3 = file3;
	}

	public MultipartFile getFile4() {
		return file4;
	}

	public void setFile4(MultipartFile file4) {
		this.file4 = file4;
	}

	public MultipartFile getFile5() {
		return file5;
	}

	public void setFile5(MultipartFile file5) {
		this.file5 = file5;
	}

	public String getPro_img1() {
		return pro_img1;
	}

	public void setPro_img1(String pro_img1) {
		this.pro_img1 = pro_img1;
	}

	public String getPro_img2() {
		return pro_img2;
	}

	public void setPro_img2(String pro_img2) {
		this.pro_img2 = pro_img2;
	}

	public String getPro_img3() {
		return pro_img3;
	}

	public void setPro_img3(String pro_img3) {
		this.pro_img3 = pro_img3;
	}

	public String getPro_img4() {
		return pro_img4;
	}

	public void setPro_img4(String pro_img4) {
		this.pro_img4 = pro_img4;
	}

	public String getPro_img5() {
		return pro_img5;
	}

	public void setPro_img5(String pro_img5) {
		this.pro_img5 = pro_img5;
	}

	
	
}
