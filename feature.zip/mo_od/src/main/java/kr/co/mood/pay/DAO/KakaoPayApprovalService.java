package kr.co.mood.pay.DAO;

import kr.co.mood.Payment.VO.KakaoPayApprovalVO;

public interface KakaoPayApprovalService {
	
	public void paymentinsert(KakaoPayApprovalVO kvo);

}
