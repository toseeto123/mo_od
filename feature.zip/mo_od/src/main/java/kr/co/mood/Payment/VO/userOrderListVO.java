package kr.co.mood.Payment.VO;

import java.util.List;

public class userOrderListVO {

	private List<userOrderVO> orders;

	public List<userOrderVO> getOrders() {
		return orders;
	}

	public void setOrders(List<userOrderVO> orders) {
		this.orders = orders;
	}
	
}
