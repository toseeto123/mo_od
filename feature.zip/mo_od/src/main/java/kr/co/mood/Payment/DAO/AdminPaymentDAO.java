package kr.co.mood.Payment.DAO;

import java.util.List;

import kr.co.mood.Payment.VO.AdminPaymentVO;

public interface AdminPaymentDAO {
	public List<AdminPaymentVO> getadminPayment();
}
